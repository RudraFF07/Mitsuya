setInterval(() => {
  let My1 = new Date()
  let NewYear = My1.getFullYear()
  let Todaydate = My1.getDate()
  let Min = My1.getMinutes()
  let Sec = My1.getSeconds()
        let Ganta = My1.getHours()
        let mahina = My1.getMonth();
        let AMAndPM = '';
        if(Ganta==12 || Ganta>12){
          AMAndPM = ' PM'
        }  
        else{
          AMAndPM = ' AM'
        }
        document.getElementById('Time').innerHTML =  Ganta + ':' + Min + ':' + Sec + AMAndPM +'<br>' + NewYear + '/' + parseInt(mahina+1) +'/' + Todaydate ;
      }, 1000);

    var $page = $('.page');

    $('.menu_toggle').on('click', function(){
      $page.toggleClass('shazam');
    });
    $('.content').on('click', function(){
      $page.removeClass('shazam');
    });
 $('#Wifi-btn').click(function (){
   $('#Wifi-btn').toggleClass("Wifi-Active-Blue");
 })
 $('.Icon').click(function (){
   document.getElementById('Active-App').innerHTML = 'Starting Application'
 })
 $('#Youtube').click(function (){
   $('#Youtube').append('<iframe src="Luck.html" id="iframe-yt" title="W3Schools Free Online Web Tutorials"></iframe>')
 })
$('#google-search').focus(function (){
})
setInterval(() => {
  query = document.getElementById('google-search').value
}, 10);
//                        ====================================Google Search=====================
$('#goSearch').click(function (){
  if(query!=''){
    console.log('lets go')
    let query = document.getElementById('google-search').value
    var str = 'Your Search Is Ready :' + query ;
    var result = str.link("http://google.com/search?q="+query);
    document.getElementById('demo').innerHTML = result
  }
})
$('#Active').click(function  (){
  $(this).addClass('ActiveRotating')
  $(this).dblclick(function (){
    $(this).removeClass('ActiveRotating')
    $(this).addClass('EasterEgg')
    $(this).click(function (){
    $(this).removeClass('EasterEgg')
    })
  })
})

//                        ====================================Prevoius Theme=====================
CheckingDarkMode = () =>{
  if(localStorage.getItem('Theme')=="Dark"){
    $('#Dock,#Status-bar,#Google,#google-search,#Sound,#Wifi-btn,#Quick-Actions').addClass('Dark-ModeOn')
    $('#Dock,#Status-bar,#Google,#google-search,#Sound,#Wifi-btn,#Quick-Actions').removeClass('Dark-ModeOff')
    $('svg,#Status-bar h6,#google-search').css('color','white')
    $('#Home-Screen').css('background-image','url(https://images.hdqwalls.com/wallpapers/dark-flow-facets-nm.jpg)')
    $('.switch').addClass('Dark-Mode-Input-Text-White')
    document.querySelector('#Dark-Mode').checked = true
    if(localStorage.getItem('Icon')=='Static'){
      $('#Dock svg').css('color','white')
    }
    $('#Quick-Actions h4,#Quick-Actions h6,#Quick-Actions b').css('color','#fff')
  }
  else{
    $('#Quick-Actions h4,#Quick-Actions h6,#Quick-Actions b').css('color','#1d1b1b')
    $('#Quick-Actions b').css('color','#1d1b1b')
  }
}
$('#Dark-Mode').click(function () {
  DarkMode()
})
setTimeout(() => {
  $('#Dock,#Status-bar,#Google,#google-search,#Sound,#Wifi-btn,#Quick-Actions').addClass('Dark-ModeOff')
}, 10);
//                        ====================================Dark Or Light Mode fx=====================

DarkMode = ()=>{
  if(document.querySelector('#Dark-Mode').checked == true){
    $('#Dock,#Status-bar,#Google,#google-search,#Sound,#Wifi-btn,#Quick-Actions').addClass('Dark-ModeOn')
    $('#Dock,#Status-bar,#Google,#google-search,#Sound,#Wifi-btn,#Quick-Actions').removeClass('Dark-ModeOff')
    $('svg,#Status-bar h6,#google-search').css('color','white')
    $('.switch').addClass('Dark-Mode-Input-Text-White')
    $('#Home-Screen').css('background-image','url(https://images.hdqwalls.com/wallpapers/dark-flow-facets-nm.jpg)')
    localStorage.setItem('Theme','Dark')
    if(localStorage.getItem('Icon')=='Static'){
      $('#Dock svg').css('color','white')
    }
  }
  else{
    $('#Dock,#Status-bar,#Google,#google-search,#Sound,#Wifi-btn,#Quick-Actions').addClass('Dark-ModeOff')
    $('#Dock,#Status-bar,#Google,#google-search,#Sound,#Wifi-btn,#Quick-Actions').removeClass('Dark-ModeOn')
    $('#Home-Screen').css('background-image','url(https://www.pixel4k.com/wp-content/uploads/2018/10/iceberg-minimalist-4k_1540752916.jpg)')
    $('svg,#Status-bar h6,#google-search').css('color','black')
    $('.switch').removeClass('Dark-Mode-Input-Text-White')
    localStorage.setItem('Theme',"Light")

  }
}
let x = 0;
$('#Expand').click(function (){
  // $(this).addClass('ExpandTransform') 
  QuickAction = ()=>{}
  if(x==0){
    $('#Quick-Actions').show(500);
    x=1;
  }
  else{
    $('#Quick-Actions').hide(500);

    x=0;
  }
})
// Function X 
window.onload = function(){
  //hide the preloader
  document.querySelector(".preloader").style.display = "none";
}
setTimeout(() => {
  if(localStorage.getItem('Theme')=='Dark'){
    CheckingDarkMode()
  }
  else{
    //
  }
}, 11);
// Notification 
$('.Important-Notification').click(function(){
  if(x==0){
    document.getElementById('Quick-Actions').style.display = 'block'
    x=1;
  }
  else{
    document.getElementById('Quick-Actions').style.display = 'none'
    x=0;
  }
})
console.log(" What's New In v1-21.07.14 \n || New Icon Pack (Color Icons) || \n || New Dock Animation || \n || Buy Fixes || \n || Preloader Update || \n v1.21.08.22 \n || New Animation Added In Dark Mode, Wallpaper And Quick Actions || \n || Source Code Improved ||")
xyz = 0;
//Navigation Buttons
let xz = 1
FullScreen = () =>{
  if(xz == 1){
  $('#Dock,#Status-bar,.menu_toggle').hide('swing')
  $('.outer').addClass('FullScreen')
  $('#AddBtn,.what-todo').addClass('mtb5')
  xz = 0
  }
  else {
    $('#Dock,#Status-bar,.menu_toggle').show("linear")
    $('.outer').removeClass('FullScreen') 
  $('#AddBtn,.what-todo').removeClass('mtb5')
  xz = 1
  }
}
  //                 ================================== App Window=====================================
 AppWindow = () =>{
    $('body').append('<div class="outer dark"><div class="dot red"></div><div class="dot amber" onclick="FullScreen()"></div><div class="dot green"></div><div class="All-Remove"><div class="contine"><div class="gg-bound-control" data-bound-control><div class="gg-bound-control-outer"><div class="gg-bound-control-inner"><div class="gg-bound-control-wrapper"><input id="AddInput" class="gg-bound-control-input" type="text" spellcheck="false" autocomplete="off" autocapitalize="none" name="App Url"><div class="gg-bound-control-label">App Url</div></div><div class="gg-bound-control-df-bottom-border"></div><div class="gg-bound-control-ef-bottom-border"></div></div></div></div></div><p style="text-align:center;color:white;margin-top:50px;margin-bottom;50px;">Only Type File Name Without .html or .htm</p><h5 class="what-todo">Just Type The Url Of File From Your Computer OrInternet And Click Ok!</h5><br><center> <h5 id"AddAppName"></h5> <div class="col-md-3 col-sm-3 col-xs-6"> <a href="#" id="AddBtn" onclick="AddingApp()" class="btn btn-sm animated-button victoria-two">Ok!</a> </div></center></div></div>')
    $('#Home-Screen').css('filter','blur(8px)','-webkit-filter','blur(8px)')
    $('.red').click(function (){
      $('#Dock,#Status-bar,.menu_toggle').show()
      $('.outer').detach()
    $('#Home-Screen').css('filter','blur(0px)','-webkit-filter','blur(0px)')
    })
    $('.gg-bound-control-input').click(function (){
    $('.gg-bound-control-label').css('margin-bottom','10px')
  })
  $('.gg-bound-control-input').blur(function (){
   let AddAppValue = document.querySelector('.gg-bound-control-input').value.length
    if(AddAppValue > 0){
      $('.gg-bound-control-label').css('display','none')
    }
    else{
      $('.gg-bound-control-label').css('display','block')
    $('.gg-bound-control-label').css('margin-bottom','0px')
    }
  })
}

//                        ====================================Adding App=====================

AddingApp = ()=>{
  console.log('Hello')
  let AddInputVal = $('#AddInput').val()
  if($('.gg-bound-control-input').val()==""){
    alert('Please Enter File Name')
  }
  else{
    console.log(AddInputVal)
    $('.outer').append("<iframe class='AppFrame' src='"+ AddInputVal +"' height='200' width='300' title='Iframe Example'></iframe>")
    $('.All-Remove').detach()
    $('.outer').css('opacity','100%')
  }
}
//                        ====================================Icon Toggle=====================
  let ChangeIcon = document.querySelector('#Color-Icon')
  ColorIcon = () =>{
    document.querySelector('#Color-Icon').checked = true
    $('#Dock svg').detach()
    $('#Dock').css('opacity','90%')
    $('#Dock').append('<img src="https://img.icons8.com/color/84/000000/youtube-play.svg"/><img src="https://img.icons8.com/color/100/000000/facebook-new.svg"/><img src="https://img.icons8.com/color/100/000000/whatsapp.svg"/><img src="https://img.icons8.com/color/84/000000/instagram-new.svg"/><img src="https://img.icons8.com/color/84/000000/apple-mail.svg"/> <img id="setting" src="https://img.icons8.com/color/48/000000/settings--v1.svg"/><img src="https://img.icons8.com/color/2x/google-play-music.svg"/><img src="https://img.icons8.com/color/2x/clock--v4.svg"><img src="https://img.icons8.com/color/2x/google-images.svg"/><img src="https://img.icons8.com/color/84/000000/picture.svg"/><img src="https://img.icons8.com/color/48/000000/apple-arcade.svg"/><img id="Edge" src="https://img.icons8.com/color/2x/ms-edge-new.svg"/><img id="AddNewApp" src="https://img.icons8.com/office/2x/plus.svg"/>')
    $('.Which-Icon').text('Icon : Color')
    $('#AddNewApp').click(function (){
      AppWindow()
    }) 
    $('#setting').click(function (){
      LaunchSettings()
    })
    localStorage.setItem('Icon','Color')
  }
  StaticIcon = () =>{
    setTimeout(() => {
      if(localStorage.getItem('Theme') == 'Dark'){
        $('#Dock svg').css('color','white')
      }
    document.querySelector('#Color-Icon').checked = false
    }, 100);
    if($('#Dock svg').detach() == false){
      $('#Dock svg').detach()
    }
    else{
    $('#Dock img').detach()
    $('#Dock').css('opacity','43%')
    $('#Dock').append('<svg id="Whatsapp" class="Icon" xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-asterisk" viewBox="0 0 16 16"> <path d="M8 0a1 1 0 0 1 1 1v5.268l4.562-2.634a1 1 0 1 1 1 1.732L10 8l4.562 2.634a1 1 0 1 1-1 1.732L9 9.732V15a1 1 0 1 1-2 0V9.732l-4.562 2.634a1 1 0 1 1-1-1.732L6 8 1.438 5.366a1 1 0 0 1 1-1.732L7 6.268V1a1 1 0 0 1 1-1z"/> </svg><svg id="Facebook" class="Icon" xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-facebook" viewBox="0 0 16 16"> <path d="M16 8.049c0-4.446-3.582-8.05-8-8.05C3.58 0-.002 3.603-.002 8.05c0 4.017 2.926 7.347 6.75 7.951v-5.625h-2.03V8.05H6.75V6.275c0-2.017 1.195-3.131 3.022-3.131.876 0 1.791.157 1.791.157v1.98h-1.009c-.993 0-1.303.621-1.303 1.258v1.51h2.218l-.354 2.326H9.25V16c3.824-.604 6.75-3.934 6.75-7.951z" /> </svg> <svg id="Youtube" class="Icon" xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-youtube" viewBox="0 0 16 16"> <path d="M8.051 1.999h.089c.822.003 4.987.033 6.11.335a2.01 2.01 0 0 1 1.415 1.42c.101.38.172.883.22 1.402l.01.104.022.26.008.104c.065.914.073 1.77.074 1.957v.075c-.001.194-.01 1.108-.082 2.06l-.008.105-.009.104c-.05.572-.124 1.14-.235 1.558a2.007 2.007 0 0 1-1.415 1.42c-1.16.312-5.569.334-6.18.335h-.142c-.309 0-1.587-.006-2.927-.052l-.17-.006-.087-.004-.171-.007-.171-.007c-1.11-.049-2.167-.128-2.654-.26a2.007 2.007 0 0 1-1.415-1.419c-.111-.417-.185-.986-.235-1.558L.09 9.82l-.008-.104A31.4 31.4 0 0 1 0 7.68v-.122C.002 7.343.01 6.6.064 5.78l.007-.103.003-.052.008-.104.022-.26.01-.104c.048-.519.119-1.023.22-1.402a2.007 2.007 0 0 1 1.415-1.42c.487-.13 1.544-.21 2.654-.26l.17-.007.172-.006.086-.003.171-.007A99.788 99.788 0 0 1 7.858 2h.193zM6.4 5.209v4.818l4.157-2.408L6.4 5.209z" /> </svg> <svg id="insta" class="Icon" xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-instagram" viewBox="0 0 16 16"> <path d="M8 0C5.829 0 5.556.01 4.703.048 3.85.088 3.269.222 2.76.42a3.917 3.917 0 0 0-1.417.923A3.927 3.927 0 0 0 .42 2.76C.222 3.268.087 3.85.048 4.7.01 5.555 0 5.827 0 8.001c0 2.172.01 2.444.048 3.297.04.852.174 1.433.372 1.942.205.526.478.972.923 1.417.444.445.89.719 1.416.923.51.198 1.09.333 1.942.372C5.555 15.99 5.827 16 8 16s2.444-.01 3.298-.048c.851-.04 1.434-.174 1.943-.372a3.916 3.916 0 0 0 1.416-.923c.445-.445.718-.891.923-1.417.197-.509.332-1.09.372-1.942C15.99 10.445 16 10.173 16 8s-.01-2.445-.048-3.299c-.04-.851-.175-1.433-.372-1.941a3.926 3.926 0 0 0-.923-1.417A3.911 3.911 0 0 0 13.24.42c-.51-.198-1.092-.333-1.943-.372C10.443.01 10.172 0 7.998 0h.003zm-.717 1.442h.718c2.136 0 2.389.007 3.232.046.78.035 1.204.166 1.486.275.373.145.64.319.92.599.28.28.453.546.598.92.11.281.24.705.275 1.485.039.843.047 1.096.047 3.231s-.008 2.389-.047 3.232c-.035.78-.166 1.203-.275 1.485a2.47 2.47 0 0 1-.599.919c-.28.28-.546.453-.92.598-.28.11-.704.24-1.485.276-.843.038-1.096.047-3.232.047s-2.39-.009-3.233-.047c-.78-.036-1.203-.166-1.485-.276a2.478 2.478 0 0 1-.92-.598 2.48 2.48 0 0 1-.6-.92c-.109-.281-.24-.705-.275-1.485-.038-.843-.046-1.096-.046-3.233 0-2.136.008-2.388.046-3.231.036-.78.166-1.204.276-1.486.145-.373.319-.64.599-.92.28-.28.546-.453.92-.598.282-.11.705-.24 1.485-.276.738-.034 1.024-.044 2.515-.045v.002zm4.988 1.328a.96.96 0 1 0 0 1.92.96.96 0 0 0 0-1.92zm-4.27 1.122a4.109 4.109 0 1 0 0 8.217 4.109 4.109 0 0 0 0-8.217zm0 1.441a2.667 2.667 0 1 1 0 5.334 2.667 2.667 0 0 1 0-5.334z" /> </svg> <svg id="email" class="Icon" xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-envelope" viewBox="0 0 16 16"> <path d="M0 4a2 2 0 0 1 2-2h12a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H2a2 2 0 0 1-2-2V4zm2-1a1 1 0 0 0-1 1v.217l7 4.2 7-4.2V4a1 1 0 0 0-1-1H2zm13 2.383l-4.758 2.855L15 11.114v-5.73zm-.034 6.878L9.271 8.82 8 9.583 6.728 8.82l-5.694 3.44A1 1 0 0 0 2 13h12a1 1 0 0 0 .966-.739zM1 11.114l4.758-2.876L1 5.383v5.73z" /> </svg> <svg id="setting"  class="Icon" xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-gear-fill" viewBox="0 0 16 16"> <path d="M9.405 1.05c-.413-1.4-2.397-1.4-2.81 0l-.1.34a1.464 1.464 0 0 1-2.105.872l-.31-.17c-1.283-.698-2.686.705-1.987 1.987l.169.311c.446.82.023 1.841-.872 2.105l-.34.1c-1.4.413-1.4 2.397 0 2.81l.34.1a1.464 1.464 0 0 1 .872 2.105l-.17.31c-.698 1.283.705 2.686 1.987 1.987l.311-.169a1.464 1.464 0 0 1 2.105.872l.1.34c.413 1.4 2.397 1.4 2.81 0l.1-.34a1.464 1.464 0 0 1 2.105-.872l.31.17c1.283.698 2.686-.705 1.987-1.987l-.169-.311a1.464 1.464 0 0 1 .872-2.105l.34-.1c1.4-.413 1.4-2.397 0-2.81l-.34-.1a1.464 1.464 0 0 1-.872-2.105l.17-.31c.698-1.283-.705-2.686-1.987-1.987l-.311.169a1.464 1.464 0 0 1-2.105-.872l-.1-.34zM8 10.93a2.929 2.929 0 1 1 0-5.86 2.929 2.929 0 0 1 0 5.858z" /> </svg> <svg id="music" class="Icon" xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-file-music" viewBox="0 0 16 16"> <path d="M10.304 3.13a1 1 0 0 1 1.196.98v1.8l-2.5.5v5.09c0 .495-.301.883-.662 1.123C7.974 12.866 7.499 13 7 13c-.5 0-.974-.134-1.338-.377-.36-.24-.662-.628-.662-1.123s.301-.883.662-1.123C6.026 10.134 6.501 10 7 10c.356 0 .7.068 1 .196V4.41a1 1 0 0 1 .804-.98l1.5-.3z" /> <path d="M4 0a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h8a2 2 0 0 0 2-2V2a2 2 0 0 0-2-2H4zm0 1h8a1 1 0 0 1 1 1v12a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1z" /> </svg> <svg id="alarm" class="Icon" xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-alarm" viewBox="0 0 16 16"> <path d="M8.5 5.5a.5.5 0 0 0-1 0v3.362l-1.429 2.38a.5.5 0 1 0 .858.515l1.5-2.5A.5.5 0 0 0 8.5 9V5.5z" /> <path d="M6.5 0a.5.5 0 0 0 0 1H7v1.07a7.001 7.001 0 0 0-3.273 12.474l-.602.602a.5.5 0 0 0 .707.708l.746-.746A6.97 6.97 0 0 0 8 16a6.97 6.97 0 0 0 3.422-.892l.746.746a.5.5 0 0 0 .707-.708l-.601-.602A7.001 7.001 0 0 0 9 2.07V1h.5a.5.5 0 0 0 0-1h-3zm1.038 3.018a6.093 6.093 0 0 1 .924 0 6 6 0 1 1-.924 0zM0 3.5c0 .753.333 1.429.86 1.887A8.035 8.035 0 0 1 4.387 1.86 2.5 2.5 0 0 0 0 3.5zM13.5 1c-.753 0-1.429.333-1.887.86a8.035 8.035 0 0 1 3.527 3.527A2.5 2.5 0 0 0 13.5 1z" /> </svg> <svg id="cam" class="Icon" xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-camera2" viewBox="0 0 16 16"> <path d="M5 8c0-1.657 2.343-3 4-3V4a4 4 0 0 0-4 4z" /> <path d="M12.318 3h2.015C15.253 3 16 3.746 16 4.667v6.666c0 .92-.746 1.667-1.667 1.667h-2.015A5.97 5.97 0 0 1 9 14a5.972 5.972 0 0 1-3.318-1H1.667C.747 13 0 12.254 0 11.333V4.667C0 3.747.746 3 1.667 3H2a1 1 0 0 1 1-1h1a1 1 0 0 1 1 1h.682A5.97 5.97 0 0 1 9 2c1.227 0 2.367.368 3.318 1zM2 4.5a.5.5 0 1 0-1 0 .5.5 0 0 0 1 0zM14 8A5 5 0 1 0 4 8a5 5 0 0 0 10 0z" /> </svg> <svg id="Gallery" class="Icon" xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-image" viewBox="0 0 16 16"> <path d="M6.002 5.5a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0z" /> <path d="M2.002 1a2 2 0 0 0-2 2v10a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V3a2 2 0 0 0-2-2h-12zm12 1a1 1 0 0 1 1 1v6.5l-3.777-1.947a.5.5 0 0 0-.577.093l-3.71 3.71-2.66-1.772a.5.5 0 0 0-.63.062L1.002 12V3a1 1 0 0 1 1-1h12z" /> </svg> <svg id="con" class="Icon" xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-controller" viewBox="0 0 16 16"> <path d="M11.5 6.027a.5.5 0 1 1-1 0 .5.5 0 0 1 1 0zm-1.5 1.5a.5.5 0 1 0 0-1 .5.5 0 0 0 0 1zm2.5-.5a.5.5 0 1 1-1 0 .5.5 0 0 1 1 0zm-1.5 1.5a.5.5 0 1 0 0-1 .5.5 0 0 0 0 1zm-6.5-3h1v1h1v1h-1v1h-1v-1h-1v-1h1v-1z" /> <path d="M3.051 3.26a.5.5 0 0 1 .354-.613l1.932-.518a.5.5 0 0 1 .62.39c.655-.079 1.35-.117 2.043-.117.72 0 1.443.041 2.12.126a.5.5 0 0 1 .622-.399l1.932.518a.5.5 0 0 1 .306.729c.14.09.266.19.373.297.408.408.78 1.05 1.095 1.772.32.733.599 1.591.805 2.466.206.875.34 1.78.364 2.606.024.816-.059 1.602-.328 2.21a1.42 1.42 0 0 1-1.445.83c-.636-.067-1.115-.394-1.513-.773-.245-.232-.496-.526-.739-.808-.126-.148-.25-.292-.368-.423-.728-.804-1.597-1.527-3.224-1.527-1.627 0-2.496.723-3.224 1.527-.119.131-.242.275-.368.423-.243.282-.494.575-.739.808-.398.38-.877.706-1.513.773a1.42 1.42 0 0 1-1.445-.83c-.27-.608-.352-1.395-.329-2.21.024-.826.16-1.73.365-2.606.206-.875.486-1.733.805-2.466.315-.722.687-1.364 1.094-1.772a2.34 2.34 0 0 1 .433-.335.504.504 0 0 1-.028-.079zm2.036.412c-.877.185-1.469.443-1.733.708-.276.276-.587.783-.885 1.465a13.748 13.748 0 0 0-.748 2.295 12.351 12.351 0 0 0-.339 2.406c-.022.755.062 1.368.243 1.776a.42.42 0 0 0 .426.24c.327-.034.61-.199.929-.502.212-.202.4-.423.615-.674.133-.156.276-.323.44-.504C4.861 9.969 5.978 9.027 8 9.027s3.139.942 3.965 1.855c.164.181.307.348.44.504.214.251.403.472.615.674.318.303.601.468.929.503a.42.42 0 0 0 .426-.241c.18-.408.265-1.02.243-1.776a12.354 12.354 0 0 0-.339-2.406 13.753 13.753 0 0 0-.748-2.295c-.298-.682-.61-1.19-.885-1.465-.264-.265-.856-.523-1.733-.708-.85-.179-1.877-.27-2.913-.27-1.036 0-2.063.091-2.913.27z" /> </svg><svg width="44" id="Edge" class="Icon" height="44" viewBox="0 0 44 44" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M22.3058 -9.34601e-05C12.4475 -9.34601e-05 4.04526 6.17586 1.00309 15.6464C0.570128 16.9935 0.28559 18.3329 0.133953 19.6542C0.130634 19.6622 0.1275 19.6696 0.124187 19.6776L0.130047 19.6796C-0.932664 29.043 4.67831 37.4904 11.4504 41.2675C12.6305 41.9266 16.7168 43.9505 22.298 43.9843C22.3413 43.9911 22.385 43.995 22.4289 43.996C27.3047 43.996 34.3047 42.4358 40.2648 34.7265C40.2708 34.7181 40.2767 34.7096 40.2824 34.7011C40.3149 34.6562 40.3472 34.6133 40.3781 34.5683C40.5014 34.3893 40.563 34.1751 40.5537 33.958C40.5443 33.7409 40.4646 33.5328 40.3264 33.3651C40.1883 33.1974 39.9993 33.0792 39.788 33.0285C39.5767 32.9777 39.3547 32.9972 39.1554 33.0839C38.9909 33.1552 38.8262 33.2309 38.6711 33.3007C38.6704 33.3013 38.6698 33.302 38.6691 33.3026C38.3104 33.4653 37.953 33.5582 37.2336 33.8534C37.2329 33.8534 37.2323 33.8534 37.2316 33.8534C36.0294 34.3482 34.0593 34.6835 31.9718 34.6835C30.225 34.6835 28.5119 34.4544 27.2218 34.0663C25.2311 33.4671 19.6291 31.8153 16.6183 25.1737C15.8824 23.5525 15.5913 20.9092 17.0968 18.5468C18.0591 17.0381 20.0256 15.9862 22.0148 15.9862C23.234 15.9862 24.4147 16.3602 25.4504 17.08C27.0442 18.1887 27.6612 19.444 27.9035 20.6249C28.1458 21.8058 27.9653 22.9219 27.8058 23.5409C27.4922 24.7617 27.0993 25.2209 26.8957 25.4745C26.8917 25.479 26.8878 25.4836 26.884 25.4882C26.884 25.4882 26.8442 25.5366 26.7765 25.6269C26.6284 25.825 26.559 26.0711 26.5817 26.3175C26.6044 26.5639 26.7177 26.7931 26.8996 26.9608C27.0017 27.0551 27.1084 27.1343 27.2414 27.2167L27.5011 27.3788C28.9041 28.2561 31.5716 28.996 34.2355 28.996C36.272 28.996 38.9125 28.5946 41.2648 26.2401C43.322 24.1807 43.9581 21.6507 43.9933 19.5136C44.0285 17.3764 43.4993 15.5912 43.2082 14.7616C42.2078 11.9123 38.0511 2.59887 26.5773 0.404203C25.1734 0.135153 23.7381 -9.33601e-05 22.3058 -9.34601e-05ZM22.3058 1.99991C23.6115 1.99991 24.9242 2.1241 26.2023 2.36905C36.7385 4.38438 40.4379 12.9071 41.3215 15.4237C41.5623 16.1102 42.0227 17.699 41.9933 19.4804C41.964 21.2617 41.4815 23.1935 39.8507 24.8261C37.925 26.7536 36.049 26.996 34.2355 26.996C32.172 26.996 29.8309 26.2743 28.8976 25.8046C29.1899 25.3497 29.483 25.0526 29.7433 24.039C29.9528 23.226 30.1912 21.8247 29.8625 20.2226C29.7674 19.7594 29.6139 19.2796 29.4054 18.7987L29.4113 18.7968C27.7752 14.0283 22.3616 10.0018 16.3586 9.17764C12.1289 8.59694 7.56787 9.77917 3.99723 13.537C7.37992 6.4223 14.2602 1.99991 22.3058 1.99991ZM14.1027 11.0233C14.7651 11.0213 15.427 11.0678 16.0851 11.1581C18.6656 11.5124 21.1494 12.6097 23.1672 14.0761C22.787 14.0198 22.4022 13.9862 22.0148 13.9862C20.2605 13.9862 18.5613 14.5659 17.2062 15.5722L17.2043 15.5702C17.1358 15.6219 17.0764 15.6764 17.009 15.7284C16.8756 15.8345 16.7381 15.936 16.6125 16.0507C9.97117 21.4226 8.85429 28.5574 11.1203 34.1718C12.2691 37.0181 14.2588 39.4961 16.7629 41.2206C14.5642 40.6216 13.0043 39.845 12.425 39.5214C6.40785 36.1653 1.28201 28.5558 2.10856 20.1405C4.98835 13.4053 9.53511 11.0373 14.1027 11.0233ZM14.0324 21.8046C13.9518 23.3799 14.2768 24.8518 14.798 25.9999C18.1492 33.3923 24.6564 35.3816 26.6457 35.9804C28.1876 36.4443 30.0547 36.6835 31.9718 36.6835C33.4397 36.6835 34.7801 36.4992 36.0207 36.2304C32.4357 39.6662 28.7621 41.1736 25.5617 41.7245C20.0026 42.1155 14.9963 38.4279 12.9757 33.4218C11.5397 29.8637 11.5701 25.6981 14.0324 21.8046Z" fill="black"></path></svg> <svg id="AddNewApp" xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-plus-circle-fill" viewBox="0 0 16 16"> <path d="M16 8A8 8 0 1 1 0 8a8 8 0 0 1 16 0zM8.5 4.5a.5.5 0 0 0-1 0v3h-3a.5.5 0 0 0 0 1h3v3a.5.5 0 0 0 1 0v-3h3a.5.5 0 0 0 0-1h-3v-3z"/> </svg>')
    $('#AddNewApp').click(function (){
      AppWindow()
    })}
    $('#setting').click(function (){
      LaunchSettings()
    })
    $('.Which-Icon').text('Icon : Static')
    localStorage.setItem('Icon','Static')
  }
$('#Color-Icon').click(function (){
  if(ChangeIcon.checked == true){
    ColorIcon()
  }
  else{
    StaticIcon()
  }
})
$(document).ready(function (){
  if(localStorage.getItem('Icon') == 'Color'){
    ColorIcon()
  }
  else{
    StaticIcon()
  }
})

// Wallpaper Changing (Slideshow)
// $(document).ready(function (){
//   setInterval(() => {
//     SlideShow()
//   }, 5000);
// })
// let WallX = 0
// SlideShow = () =>{
//   if(WallX == 0){
//   $('#Home-Screen').css('background-image','url(https://appleinformed.files.wordpress.com/2021/06/macosmontereywallpaper.jpg)')
//   setTimeout(() => {
//     WallX = 1
//   }, 5000);
//   }
//   else if(WallX == 1){
//     $('#Home-Screen').css('background-image','url(https://images5.alphacoders.com/113/1132429.jpg)')
//     setTimeout(() => {
//       WallX = 0
//     }, 5000);
//   }
// }
// Wallpaper Slide Show 

// let HomeScreen = $('#Home-Screen')
// let WallX = 0
// setInterval(() => {
//   if(WallX == 0){
//     HomeScreen.css('background','url(https://970-096c3220-07a7-4abe-9f67-5ef097922665.cs-asia-southeast1-ajrg.cloudshell.dev/files/download/?id=8e0a33a1-2064-4be1-9088-0814f8452fc5)')
//     WallX = 1
//   }
//   else if(WallX == 1){
//     HomeScreen.css('background','url(https://970-096c3220-07a7-4abe-9f67-5ef097922665.cs-asia-southeast1-ajrg.cloudshell.dev/files/download/?id=a2514a29-18e0-4eb7-81ce-414c44559a23)')
//     WallX = 2
//   }
//   else if(WallX == 2){
//     HomeScreen.css('background','url(https://970-096c3220-07a7-4abe-9f67-5ef097922665.cs-asia-southeast1-ajrg.cloudshell.dev/files/download/?id=5b626f64-22b1-4471-9f60-a862af4fb163)')
//     WallX = 3
//   }
//   else if(WallX == 3){
//     HomeScreen.css('background','url(https://970-096c3220-07a7-4abe-9f67-5ef097922665.cs-asia-southeast1-ajrg.cloudshell.dev/files/download/?id=43506c46-b8a7-4ac1-a52d-3533f683f1c8)')
//     WallX = 4
//   }
//   else{
//     HomeScreen.css('background','url(https://970-096c3220-07a7-4abe-9f67-5ef097922665.cs-asia-southeast1-ajrg.cloudshell.dev/files/download/?id=47050243-58c2-436b-a434-a607d73297da)')
//     WallX = 0
//   }
// }, 10000);
// Apps Start Function
setTimeout(() => {
    $('#Edge').click(function (){
    Edge()
  })
}, 100);
