$('.Wall-Options').mouseover(function (){
    $('body').css('background','url(https://wallpaperaccess.com/full/3864693.png)') 
    $('.Big-Txt').css('color','white')
})
$('.Wall-Options').mouseout(function (){
    $('body').css('background','url()') 
    $('.Big-Txt').css('color','rgb(44, 38, 38)')
})