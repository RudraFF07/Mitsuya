window.onload = function(){
    //hide the preloader
    document.querySelector(".preloader").style.display = "none";
    // Startup Check 
}

$('#Panel-Icon').click(function (){
    $('.Action-Panel').toggleClass('Action-Panel-Visible')
})

$('.First-group .Small-Box').click(function () {
    $('.First-group .Small-Box').toggleClass('Small-Box-Active')

})
$('.Second-group .Small-Box').click(function () {
    $('.Second-group .Small-Box').toggleClass('Small-Box-Active')
})

PushNotifiaction = () =>{
    $('.Push-Notifi').addClass('Push-Notifi-Visible')
    setTimeout(() => {
    $('.Push-Notifi').removeClass('Push-Notifi-Visible')
    }, 2000);
}
let x = 0 
$('#Feature-Theme').click(function (){
    if(x==0){
        $('.More-Option').show(1000)    
        x = 1
    }    
    else{
        $('.More-Option').hide(1000)
        x = 0
    }
})
$('#Circle-Close').click(function (){
    $('.app').hide(500)
})
$('.menu-circle-amber').click(function (){
    $('.app').toggleClass('app-full-screen')
})
$('#VS-Code').click(function (){
    document.querySelector('#App-frame').src = 'https://vscode.dev'
    $('.app').show(800)
})